package com.sirdaba.sirdaba_delivery;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.util.Log;

import com.onesignal.Continue;
import com.onesignal.OneSignal;
import com.onesignal.debug.LogLevel;

public class SirDabaApp extends Application {

    private static final String TAG = "SirDabaApp";

    // ── OneSignal App ID (مأخوذ من تطبيق WebView) ─────────────────
    private static final String ONESIGNAL_APP_ID = "38ee4211-3aed-4351-81ad-7827497f6faf";

    // ── Notification Channels ──────────────────────────────────────
    public static final String CHANNEL_ORDERS  = "sirdaba_orders";
    public static final String CHANNEL_GENERAL = "sirdaba_general";

    @Override
    public void onCreate() {
        super.onCreate();

        // 1. إنشاء قنوات الإشعارات (مطلوب قبل كل شيء)
        createNotificationChannels();

        // 2. تهيئة OneSignal للإشعارات الخارجية
        initOneSignal();

        Log.d(TAG, "SirDaba Native App initialized ✓");
    }

    // ── OneSignal Init ─────────────────────────────────────────────
    private void initOneSignal() {
        // Verbose logging في وضع التطوير (احذفه في الإنتاج)
        OneSignal.getDebug().setLogLevel(LogLevel.VERBOSE);

        // تهيئة OneSignal بالـ App ID
        OneSignal.initWithContext(this, ONESIGNAL_APP_ID);

        // طلب إذن الإشعارات من المستخدم
        OneSignal.getNotifications().requestPermission(false, Continue.none());

        Log.d(TAG, "OneSignal initialized with App ID: " + ONESIGNAL_APP_ID);
    }

    // ── Notification Channels ──────────────────────────────────────
    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm == null) return;

            // قناة الطلبات - أولوية عالية جداً
            NotificationChannel orders = new NotificationChannel(
                CHANNEL_ORDERS,
                "طلبات التوصيل",
                NotificationManager.IMPORTANCE_HIGH
            );
            orders.setDescription("إشعارات الطلبات الجديدة في مدينتك");
            orders.enableVibration(true);
            orders.setVibrationPattern(new long[]{0, 400, 200, 400, 200, 400});
            orders.setShowBadge(true);
            nm.createNotificationChannel(orders);

            // قناة الإشعارات العامة
            NotificationChannel general = new NotificationChannel(
                CHANNEL_GENERAL,
                "إشعارات عامة",
                NotificationManager.IMPORTANCE_DEFAULT
            );
            general.setDescription("تحديثات وإشعارات عامة من SirDaba");
            nm.createNotificationChannel(general);

            Log.d(TAG, "Notification channels created ✓");
        }
    }
}
