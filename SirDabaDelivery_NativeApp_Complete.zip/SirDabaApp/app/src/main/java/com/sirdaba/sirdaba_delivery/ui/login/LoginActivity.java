package com.sirdaba.sirdaba_delivery.ui.login;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.messaging.FirebaseMessaging;
import com.onesignal.OneSignal;
import com.sirdaba.sirdaba_delivery.R;
import com.sirdaba.sirdaba_delivery.api.SirDabaRepository;
import com.sirdaba.sirdaba_delivery.databinding.ActivityLoginBinding;
import com.sirdaba.sirdaba_delivery.models.LoginResponse;
import com.sirdaba.sirdaba_delivery.ui.dashboard.DashboardActivity;
import com.sirdaba.sirdaba_delivery.utils.TokenManager;

public class LoginActivity extends AppCompatActivity {

    private ActivityLoginBinding binding;
    private SirDabaRepository repo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        repo = new SirDabaRepository(this);

        // ── إذا كان المستخدم مسجل دخوله مسبقاً ────────────────────
        if (TokenManager.isLoggedIn(this)) {
            goToDashboard();
            return;
        }

        setupUI();
    }

    private void setupUI() {
        // IME action
        binding.etPassword.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                performLogin();
                return true;
            }
            return false;
        });

        binding.btnLogin.setOnClickListener(v -> performLogin());
    }

    private void performLogin() {
        String email    = binding.etEmail.getText().toString().trim();
        String password = binding.etPassword.getText().toString().trim();

        // Validation
        if (email.isEmpty()) {
            binding.tilEmail.setError("أدخل البريد الإلكتروني");
            return;
        }
        if (password.isEmpty()) {
            binding.tilPassword.setError("أدخل كلمة السر");
            return;
        }
        binding.tilEmail.setError(null);
        binding.tilPassword.setError(null);

        setLoading(true);

        repo.login(email, password, new SirDabaRepository.Callback<LoginResponse>() {
            @Override
            public void onSuccess(LoginResponse data) {
                runOnUiThread(() -> {
                    setLoading(false);
                    // ── ربط OneSignal بالمستخدم بعد الدخول ─────────
                    linkOneSignalUser();
                    // ── تسجيل FCM Token مع السيرفر ──────────────────
                    registerFcmToken();
                    goToDashboard();
                });
            }

            @Override
            public void onError(String message) {
                runOnUiThread(() -> {
                    setLoading(false);
                    showError(message);
                });
            }
        });
    }

    /**
     * ربط OneSignal بـ External User ID (user_id من WP)
     * هذا يسمح بإرسال إشعارات لمستخدم محدد
     */
    private void linkOneSignalUser() {
        int userId = TokenManager.getUserId(this);
        if (userId > 0) {
            OneSignal.login(String.valueOf(userId));
        }
    }

    /**
     * تسجيل FCM Token مع السيرفر
     */
    private void registerFcmToken() {
        FirebaseMessaging.getInstance().getToken()
            .addOnSuccessListener(token -> {
                if (token != null && !token.isEmpty()) {
                    repo.registerFcmToken(token, new SirDabaRepository.Callback<>() {
                        @Override public void onSuccess(Object data) {}
                        @Override public void onError(String message) {}
                    });
                }
            });
    }

    private void goToDashboard() {
        startActivity(new Intent(this, DashboardActivity.class));
        finish();
    }

    private void setLoading(boolean loading) {
        binding.btnLogin.setEnabled(!loading);
        binding.progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        binding.tvError.setVisibility(View.GONE);
    }

    private void showError(String message) {
        binding.tvError.setText(message);
        binding.tvError.setVisibility(View.VISIBLE);
    }
}
